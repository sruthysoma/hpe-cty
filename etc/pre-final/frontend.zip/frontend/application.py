from flask import Flask, request, render_template, send_from_directory, current_app
from werkzeug.utils import secure_filename
import os

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("cty.html")

@app.route("/uploadFile", methods = ['GET', 'POST'])
def upload_file():
   if request.method == 'POST':
      f = request.files['file']
      f.save('./uploadedFiles/'+secure_filename(f.filename))
      return 'file uploaded successfully'

@app.route("/viewUploaded/<filename>")
def viewUploaded(filename):
    uploads = os.path.join(current_app.root_path, "uploadedFiles")
    print("\n",uploads, filename)
    return send_from_directory(directory=uploads, path=filename)

if __name__ =='__main__':
    app.run(debug=True)